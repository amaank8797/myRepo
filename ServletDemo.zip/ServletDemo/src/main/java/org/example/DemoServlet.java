package org.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/DemoServlet")
public class DemoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Connection dbConnection;

    // 1. Initialize DB Connection in init() method
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Change 'password' to your actual MySQL root password
            this.dbConnection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/demodb?useSSL=false&allowPublicKeyRetrieval=true",
                    "root",
                    "password"
            );

            // Auto-create table if not existing
            try (Statement stmt = dbConnection.createStatement()) {
                String createTableSQL = "CREATE TABLE IF NOT EXISTS demo_users ("
                        + "id INT AUTO_INCREMENT PRIMARY KEY, "
                        + "username VARCHAR(100), "
                        + "role VARCHAR(50), "
                        + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
                stmt.execute(createTableSQL);
            }
            System.out.println("[INIT SUCCESS] Database connection initialized and table verified.");
        } catch (Exception e) {
            System.err.println("[INIT ERROR] DB connection failed: " + e.getMessage());
        }
    }

    // 2. Delegate GET requests to doPost
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    // 3. Process both GET and POST requests here
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String rawUsername = request.getParameter("username");
        String rawRole = request.getParameter("role");

        if (rawUsername == null || rawUsername.trim().isEmpty()) rawUsername = "GuestUser";
        if (rawRole == null || rawRole.trim().isEmpty()) rawRole = "Developer";

        // Prefix incoming values
        String prefixedUsername = "DEMO_USER_" + rawUsername.toUpperCase();
        String prefixedRole = "ROLE_" + rawRole.toUpperCase();

        // Save entry into Database
        if (dbConnection != null) {
            String insertSQL = "INSERT INTO demo_users (username, role) VALUES (?, ?)";
            try (PreparedStatement pstmt = dbConnection.prepareStatement(insertSQL)) {
                pstmt.setString(1, prefixedUsername);
                pstmt.setString(2, prefixedRole);
                pstmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Retrieve all records from Database
        List<String> dbUserList = new ArrayList<>();
        if (dbConnection != null) {
            String selectSQL = "SELECT username, role, created_at FROM demo_users ORDER BY id DESC";
            try (PreparedStatement pstmt = dbConnection.prepareStatement(selectSQL);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    dbUserList.add(String.format("%s | %s | %s",
                            rs.getString("username"),
                            rs.getString("role"),
                            rs.getTimestamp("created_at")));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Manage Session
        HttpSession session = request.getSession(true);
        session.setAttribute("userSessionID", session.getId());
        session.setAttribute("sessionUser", prefixedUsername);

        // Manage Cookie
        Cookie userCookie = new Cookie("lastVisitedUser", rawUsername.replaceAll("\\s+", "_"));
        userCookie.setMaxAge(86400); // 1 day
        response.addCookie(userCookie);

        // Pass processed attributes to result UI
        request.setAttribute("prefixedUsername", prefixedUsername);
        request.setAttribute("prefixedRole", prefixedRole);
        request.setAttribute("dbUserList", dbUserList);

        request.getRequestDispatcher("result.jsp").forward(request, response);
    }

    // Clean up DB resources when server stops
    @Override
    public void destroy() {
        if (dbConnection != null) {
            try {
                dbConnection.close();
                System.out.println("[DESTROY] Database connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}