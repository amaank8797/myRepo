package org.example;

import java.io.File;
import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;

public class Main {
    public static void main(String[] args) throws Exception {
        Tomcat tomcat = new Tomcat();

        // Match your active port (8082)
        tomcat.setPort(8082);
        tomcat.getConnector();

        File webappDir = new File("src/webapp");
        if (!webappDir.exists()) {
            webappDir.mkdirs();
        }

        File tempDir = new File("target/tomcat-temp");
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }
        tomcat.setBaseDir(tempDir.getAbsolutePath());

        // 1. Mount WebApp Context
        Context ctx = tomcat.addWebapp("/ServletDemo", webappDir.getAbsolutePath());

        // 2. EXPLICITLY REGISTER SERVLET (Fixes 404 Error)
        Tomcat.addServlet(ctx, "DemoServlet", new DemoServlet());
        ctx.addServletMappingDecoded("/DemoServlet", "DemoServlet");

        System.out.println("=================================================");
        System.out.println(" Server starting at: http://localhost:8082/ServletDemo/index.jsp");
        System.out.println("=================================================");

        tomcat.start();
        tomcat.getServer().await();
    }
}