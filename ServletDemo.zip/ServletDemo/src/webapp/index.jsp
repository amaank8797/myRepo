<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Servlet & JSP Demo - Form</title>
</head>
<body style="font-family: Arial, sans-serif; margin: 30px;">
    <h2>User Registration Form</h2>

    <form action="DemoServlet" method="POST">
        <label for="username"><b>Enter Name:</b></label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="role"><b>Enter Role:</b></label><br>
        <input type="text" id="role" name="role" required><br><br>

        <button type="submit">Submit (POST Request)</button>
    </form>

    <hr>
    <p>Test GET Request Delegation: <a href="DemoServlet?username=JohnDoe&role=Admin">Click here to send GET Request</a></p>
</body>
</html>