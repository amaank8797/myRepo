<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="jakarta.servlet.http.Cookie" %>
<!DOCTYPE html>
<html>
<head>
    <title>Servlet Demo - Output UI</title>
</head>
<body style="font-family: Arial, sans-serif; margin: 30px;">
    <h2>Servlet Execution & Database Results</h2>

    <fieldset style="margin-bottom: 20px;">
        <legend><b>1. Prefixed Parameters</b></legend>
        <p><b>Username:</b> <%= request.getAttribute("prefixedUsername") %></p>
        <p><b>Role:</b> <%= request.getAttribute("prefixedRole") %></p>
    </fieldset>

    <fieldset style="margin-bottom: 20px;">
        <legend><b>2. DB Records (Fetched via Connection initialized in init())</b></legend>
        <ul>
        <%
            List<String> dbUsers = (List<String>) request.getAttribute("dbUserList");
            if (dbUsers != null && !dbUsers.isEmpty()) {
                for (String record : dbUsers) {
                    out.println("<li>" + record + "</li>");
                }
            } else {
                out.println("<li>No records found.</li>");
            }
        %>
        </ul>
    </fieldset>

    <fieldset style="margin-bottom: 20px;">
        <legend><b>3. Session Details</b></legend>
        <p><b>Session ID:</b> <%= session.getAttribute("userSessionID") %></p>
        <p><b>Session User:</b> <%= session.getAttribute("sessionUser") %></p>
    </fieldset>

    <fieldset style="margin-bottom: 20px;">
        <legend><b>4. Received Cookies</b></legend>
        <ul>
        <%
            Cookie[] cookies = request.getCookies();
            if (cookies != null && cookies.length > 0) {
                for (Cookie c : cookies) {
                    out.println("<li><b>" + c.getName() + ":</b> " + c.getValue() + "</li>");
                }
            } else {
                out.println("<li>No cookies sent on initial request (refresh page to see stored cookie).</li>");
            }
        %>
        </ul>
    </fieldset>

    <a href="index.jsp">Back to Input Page</a>
</body>
</html>