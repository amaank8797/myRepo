package com.amaan.consumerservice.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ConsumerController {

    private final RestTemplate restTemplate;

    @Value("${producer.base.url}")
    private String producerBaseUrl;

    public ConsumerController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/fetch-message")
    public String fetchMessage() {

        return restTemplate.getForObject(
                producerBaseUrl + "/message",
                String.class
        );
    }
}